import 'package:flutter/material.dart'; // Mengimpor package Flutter.

void main() {
  runApp(const MyApp()); // Menjalankan aplikasi.
}

class MyApp extends StatelessWidget {
  const MyApp({super.key}); // Root widget aplikasi.

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner:
          false, // MaterialApp sebagai struktur aplikasi tanpa banner debug.
      home: HomeScreen(), // Halaman utama aplikasi.
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key}); // Widget stateful untuk halaman utama.
  @override
  HomeScreenState createState() =>
      HomeScreenState(); // Membuat state untuk HomeScreen.
}

class HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0; // Variabel _currentIndex menyimpan indeks halaman yang sedang ditampilkan.
  final List<Widget> _pages = [
    // _pages adalah daftar halaman (widget) yang akan ditampilkan di layar.
    const HomePage(),
    const PesananPage(),
    const AkunPage(),
  ];

  String getGreeting() {
    // Fungsi untuk menentukan sapaan berdasarkan jam saat ini
    int hour = DateTime.now().hour;
    if (hour >= 5 && hour < 12) {
      return 'Selamat Pagi,';
    } else if (hour >= 12 && hour < 18) {
      return 'Selamat Siang,';
    } else {
      return 'Selamat Malam,';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color.fromRGBO(40, 84, 63, 100),
        elevation: 0, // Menghilangkan bayangan (shadow) pada AppBar
        title: Row(
          mainAxisAlignment: MainAxisAlignment
              .spaceBetween, // Mengatur agar Row memiliki spasi antara kiri dan kanan
          children: [// Bagian kiri: Menampilkan sapaan dan nama
            Column(
              crossAxisAlignment: CrossAxisAlignment.start, // Mengatur isi Column agar rata di sisi kiri
              children: [
                Text(getGreeting(),
                    style: const TextStyle(
                        fontSize:
                            16)), // Mengambil sapaan dari fungsi getGreeting()
                const Text( 'Sobat Fore!',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            // Spacer otomatis memberikan jarak antara Column di kiri dan waktu di kanan
            const Spacer(),
            // Bagian kanan: Menampilkan waktu saat ini
            Text(
              "${DateTime.now().hour}:${DateTime.now().minute < 10 ?
               '0${DateTime.now().minute}' : DateTime.now().minute.toString()}", // Menampilkan waktu saat ini dalam format HH:MM
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
      body: _pages[_currentIndex], // Menampilkan halaman yang sesuai dengan _currentIndex berdasarkan navigasi

      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex, // Menunjukkan indeks halaman aktif.
        onTap: (index) {
          setState(() {
            _currentIndex =
                index; // Mengubah halaman yang aktif saat item di bottom navigation dipilih.
          });
        },
        type: BottomNavigationBarType.fixed, // Menetapkan tipe navigasi menjadi 'fixed' agar semua item tetap tampil.
        items: const [
          // Item navigasi dengan ikon dan label untuk setiap tab.
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.receipt),
            label: 'Pesanan',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.account_circle),
            label: 'Akun',
          ),
        ],
        selectedItemColor: Colors.green,
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});
  // StatelessWidget untuk halaman HomePage.

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      // Menggunakan SingleChildScrollView untuk memungkinkan scroll vertikal pada konten halaman.
      child: Column(
        children: [
          // Bagian Poin
          Container(
            padding: const EdgeInsets.all(16), // Memberikan padding 16 piksel
            margin: const EdgeInsets.symmetric(
                horizontal: 16,
                vertical:8), // Margin horizontal 16 piksel dan vertikal 8 piksel
            decoration: BoxDecoration(
              color: Colors.green[700],
              borderRadius: BorderRadius.circular(
                  12), // Radius melengkung 12 piksel pada semua sudut
            ),
            child: const Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween, // Menyebar elemen dengan jarak sama
              children: [
                Row(
                  children: [
                    Icon(Icons.monetization_on, color: Colors.white),
                    SizedBox(width: 8),
                    Text( '33 Poin',
                    style: TextStyle
                    (color: Colors.white, fontSize: 16),
                    ),
                  ],
                ),
                Row(
                  children: [
                    Text('Tukarkan poinmu dengan hadiah menarik',
                      style: TextStyle(color: Colors.white, fontSize: 10),
                    ),
                    Icon(Icons.chevron_right, color: Colors.white),
                  ],
                ),
              ],
            ),
          ),
          // Banner
          Container(
            margin: const EdgeInsets.all(16), // Memberikan padding 16 piksel
            height: 200, //tinggi kontainer
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(
                  12), // Radius melengkung 12 piksel pada semua sudut
              image: const DecorationImage(
                image: AssetImage('assets/images/banner.jpg'), // Gambar yang diambil dari folder aset
                fit: BoxFit.cover, // Menyesuaikan gambar untuk menutupi seluruh area kontainer
              ),
            ),
          ),

// Pick Up dan Delivery
  Stack(
      children: [
      // Background decoration atau elemen di belakang
      Positioned.fill(
            child: Container(
            decoration: BoxDecoration(
            color: Colors.white10, // Warna latar belakang untuk Stack
            borderRadius: BorderRadius.circular(20), // Sudut melengkung untuk latar belakang
            ),
          ),
        ),
       Padding(
           padding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
             child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
             const Align(
                  alignment:Alignment.centerLeft, // Menyelaraskan teks di kiri
                  child: Text('Layanan Kami',
                  style: TextStyle(
                  fontSize: 18, // Sesuaikan ukuran dengan teks "Yang Menarik di Fore"
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                        ),
                      ),
                    ),
              const SizedBox( height:10), // Jarak vertikal antara teks dan konten berikutnya
                Row(
                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
                   children: [
                   Expanded(
                      child: Container(
                       padding: const EdgeInsets.all(16),
                       decoration: BoxDecoration(
                       color: Colors.white,
                       borderRadius: BorderRadius.circular(12),
                       boxShadow: [
                BoxShadow(
                        color: Colors.grey.withOpacity(0.5),
                        spreadRadius: 2,
                        blurRadius: 5,
                        offset: const Offset(0, 3),
                           ),
                      ],
                      ),
                  child: const Column(
                      children: [
                        Icon(Icons.store,
                            size: 40, color: Colors.black),
                            SizedBox(height: 10),
                        Text('Pick Up',style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            ),
                             ),
                        SizedBox(height: 5),
                          Text( 'Ambil di store tanpa antri',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(fontSize: 14),
                                ),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(width: 10), // Jarak antar box
                        Expanded(
                          child: Container(
                            padding: const EdgeInsets.all(16),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(12),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.grey.withOpacity(0.5),
                                  spreadRadius: 2,
                                  blurRadius: 5,
                                  offset: const Offset(0, 3),
                                ),
                              ],
                            ),
                            child: const Column(
                              children: [
                                Icon(Icons.delivery_dining,
                                    size: 40, color: Colors.black),
                                SizedBox(height: 10),
                                Text('Delivery',
                                  style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                SizedBox(height: 5),
                                Text(
                                  'Pesanan diantar ke lokasimu',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(fontSize: 14),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16), // Memberikan jarak vertikal sebesar 16 piksel antara widget

// Layanan menarik di Fore (GridView)
          Padding(
            padding: const EdgeInsets.symmetric(
                horizontal:
                    20), // Padding horizontal sebesar 20 piksel di kiri dan kanan
            child: GridView(
              shrinkWrap:
                  true, // Menyesuaikan ukuran GridView dengan tinggi konten
              // GridView dengan 2 kolom dan jarak antara elemen grid.
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2, // Menentukan jumlah kolom dalam grid
                crossAxisSpacing: 10, // Jarak horizontal antara item grid
                mainAxisSpacing: 8, // Jarak vertikal antara item grid
              ),
              children: const [
                ServiceCard(
                  title: 'Share The Sip',
                  description: 'Bagikan kode referral, dapatkan hadiah',
                  icon: Icons.share,
                  backgroundColor: Color.fromRGBO(42, 97, 72, 100),
                ),
                ServiceCard(
                  title: 'MyFore Plan',
                  description: 'Berlangganan, dapat banyak keuntungan',
                  icon: Icons.card_membership,
                  backgroundColor: Color.fromRGBO(42, 97, 72, 100),
                ),
                ServiceCard(
                  title: 'FORE Gift',
                  description: 'Rayakan momen spesial bareng Fore',
                  icon: Icons.card_giftcard,
                  backgroundColor: Color.fromRGBO(42, 97, 72, 100),
                ),
                ServiceCard(
                  title: 'Layanan Lainnya',
                  description: 'Eksplor layanan menarik lainnya',
                  icon: Icons.more_horiz,
                  backgroundColor: Color.fromRGBO(42, 97, 72, 100),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// Halaman Pesanan
class PesananPage extends StatelessWidget {
  const PesananPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Riwayat Pemesanan'),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
      ),
      body: ListView(
        children: [
          // ketika ditekan akan membuka halaman detail
          GestureDetector(
            // Mendeteksi gestur
            onTap: () {
              // Tap
              Navigator.push(
                // Navigasi antar halaman (route) dalam aplikasi
                context, // untuk mengetahui posisi widget
                MaterialPageRoute(
                  // Menentukan halaman baru yang akan dibuka
                  builder: (context) => const DetailPesananPage(
                    // Halaman baru yang dibuka saat mengetuk widget
                    orderId: '12345',
                    status: 'Selesai',
                    location: 'Fore Coffee, Jakarta',
                    date: '12 September 2024',
                  ),
                ),
              );
            },
            child: const Flexible(
              // Membuat card lebih fleksibel di dalam ListView
              child: PesananCard(
                status: 'Selesai',
                location: 'Fore Coffee, Jakarta',
                date: '12 September 2024',
              ),
            ),
          ),
          GestureDetector(
            // Card, ketika ditekan akan membuka halaman detail
            onTap: () {
              // Tap
              Navigator.push(
                // Navigasi antar halaman (route) dalam aplikasi
                context, // untuk mengetahui posisi widget saat ini dalam pohon widget.
                MaterialPageRoute(
                  // Menentukan halaman baru yang akan dibuka
                  builder: (context) => const DetailPesananPage(
                    // Halaman baru yang dibuka saat mengetuk widget
                    orderId: '67890',
                    status: 'Dalam Proses',
                    location: 'Fore Coffee, Bandung',
                    date: '15 September 2024',
                  ),
                ),
              );
            },
            child: const Flexible(
              // Membuat card lebih fleksibel di dalam ListView
              child: PesananCard(
                status: 'Dalam Proses',
                location: 'Fore Coffee, Bandung',
                date: '15 September 2024',
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// Kartu untuk menampilkan pesanan
class PesananCard extends StatelessWidget {
  final String status; // Status pesanan
  final String location; // Lokasi pesanan
  final String date; // Tanggal pesanan

  const PesananCard({
    super.key,
    required this.status,
    required this.location,
    required this.date,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.all(12), // Menambahkan margin 12 piksel di semua sisi
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12), // Mengatur radius pembulatan sudut menjadi 12 piksel
      ),
      child: Padding(
        padding: const EdgeInsets.all(16), // Menambahkan padding 16 piksel di semua sisi
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start, // Menyelaraskan anak-anak widget di awal sumbu silang (kiri untuk Column)
          children: [
            Text(
              status,
              style: const TextStyle(
                color: Colors.green,
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),
            const SizedBox(height: 8), //tinggi sized box
            Text(location, style: const TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 4), //tinggi sized box
            Text(date, style: const TextStyle(color: Colors.grey)),
            const SizedBox(height: 8), //tinggi sized box
          ],
        ),
      ),
    );
  }
}

// Halaman detail pesanan
class DetailPesananPage extends StatelessWidget {
  final String orderId;
  final String status;
  final String location;
  final String date;

  const DetailPesananPage({
    super.key,
    required this.orderId,
    required this.status,
    required this.location,
    required this.date,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Detail Pesanan'),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16), //padding 16 piksel
        child: Column(
          crossAxisAlignment:CrossAxisAlignment.start, // Menyelaraskan semua child widget
          children: [
            Text( 'Order ID: $orderId',
              style: const TextStyle(
                fontWeight: FontWeight.bold, // Mengatur teks menjadi tebal.
                fontSize: 18, // Mengatur ukuran font menjadi 18 piksel
              ),
            ),
            const SizedBox(height: 8), //tinggi 8 piksel
            Text('Status: $status',
              style: const TextStyle(fontSize: 16, color: Colors.green),
            ),
            const SizedBox(height: 8), //tinggi 8 piksel
            Text('Lokasi: $location',
              style: const TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 8), //tinggi 8 piksel
            Text('Tanggal: $date',
            style: const TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 16), //tinggi 16 piksel
            const Divider(),
            const Text('Detail Produk:',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
            ),
            const SizedBox(height: 8), //tinggi 16 piksel

            // ListTile pertama untuk item pesanan "Cappuccino".
            const ListTile(
              leading: Icon(Icons.coffee), // Ikon kopi yang ditampilkan di bagian kiri ListTile.
              title: Text('Cappuccino'), // Judul yang ditampilkan adalah "Cappuccino".
              subtitle: Text('Ukuran: Medium, Jumlah: 1'), // Subjudul yang menunjukkan ukuran dan jumlah pesanan.
              trailing: Text('Rp 25.000'), // Harga yang ditampilkan di bagian kanan ListTile.
            ),

            // ListTile kedua untuk item pesanan "Latte".
            const ListTile(
              leading: Icon(Icons.coffee), // Ikon kopi yang ditampilkan di bagian kiri ListTile.
              title: Text('Latte'), // Judul yang ditampilkan adalah "Latte".
              subtitle: Text('Ukuran: Large, Jumlah: 2'), // Subjudul yang menunjukkan ukuran dan jumlah pesanan.
              trailing: Text('Rp 60.000'), // Harga yang ditampilkan di bagian kanan ListTile.
            ),
            const SizedBox(
                height:16), // Menambahkan jarak vertikal setinggi 16 piksel antara elemen-elemen.
            const Divider(), // Membuat garis pemisah horizontal di antara elemen-elemen.
            const Text('Total Pembayaran:', // Menampilkan teks "Total Pembayaran:" sebagai label.
                style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize:18, // Menerapkan gaya teks, termasuk ketebalan teks bold dan ukuran font 18.
              ),
            ),
            const SizedBox(height: 8), // Menambahkan jarak vertikal setinggi 8 piksel sebelum total harga ditampilkan.
            const Text('Rp 85.000', // Menampilkan jumlah total pembayaran "Rp 85.000".
              style: TextStyle(
                fontSize: 16, // Menerapkan gaya teks dengan ukuran font 16.
              ),
            ),
          ],
        ),
      ),
    );
  }
}

//form edit nama
class EditNamePage extends StatefulWidget {
  final String currentName;

  const EditNamePage({super.key, required this.currentName});

  @override
  EditNamePageState createState() => EditNamePageState();
}

class EditNamePageState extends State<EditNamePage> {
  final TextEditingController _nameController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _nameController.text = widget.currentName;
  }

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Edit Name'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _nameController,
              decoration: const InputDecoration(labelText: 'Your Name'),
            ),
            const SizedBox(height: 20),
            ElevatedButton( onPressed: () {
                // Mengembalikan nama baru ke halaman sebelumnya
                Navigator.pop(context, _nameController.text);
              },
              child: const Text('Save'),
            ),
          ],
        ),
      ),
    );
  }
}

// Halaman Akun
class AkunPage extends StatefulWidget {
  const AkunPage({super.key});

  @override
  AkunPageState createState() => AkunPageState();
}

class AkunPageState extends State<AkunPage> {
  String _name = 'Catarina';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Akun'),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        elevation: 0,
      ),
      body: ListView(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                const CircleAvatar(
                  radius: 30,
                  backgroundImage: AssetImage('assets/images/pinkavatar.jpg'),
                ),
                const SizedBox(width: 16),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    GestureDetector(
                      onTap: () async {
                        // Navigasi ke halaman EditNamePage dan tunggu hasilnya
                        final newName = await Navigator.push(context,
                          MaterialPageRoute(
                            builder: (context) => EditNamePage(
                              currentName: _name,
                            ),
                          ),
                        );
                        // Jika nama baru tidak null, perbarui nama
                        if (newName != null && newName.isNotEmpty) {
                          setState(() { _name = newName;
                          });
                        }
                      },
                      child: Text(_name,
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    const Text('+6288888888',
                      style: TextStyle(color: Colors.grey),
                    ),
                  ],
                ),
              ],
            ),
          ),

          const Divider(), // Menambahkan garis pemisah horizontal di antara elemen-elemen.

          ListTile(
            title: const Text('Pembayaran'), // Menampilkan teks "Pembayaran" sebagai judul pada ListTile.
            trailing: const Icon(Icons.arrow_forward_ios), // Menambahkan ikon panah ke kanan di akhir ListTile.
            onTap: () {//tap
            },
          ),
          ListTile(
            title: const Text('Pengaturan'), // Menampilkan teks "Pengaturan" sebagai judul pada ListTile.
            trailing: const Icon(Icons.arrow_forward_ios), // Menambahkan ikon panah ke kanan di akhir ListTile.
            onTap: () {//tap
            },
          ),
          const Divider(), // Menambahkan garis pemisah horizontal di antara elemen-elemen.
          ListTile(
            title: const Text('Panduan Layanan'), // Menampilkan teks "Panduan Layanan" sebagai judul pada ListTile.
            trailing: const Icon(Icons.arrow_forward_ios), // Menambahkan ikon panah ke kanan di akhir ListTile.
            onTap: () {//tap
            },
          ),
          ListTile(
            title: const Text('Kebijakan Privasi'), // Menampilkan teks "Kebijakan Privasi" sebagai judul pada ListTile.
            trailing: const Icon(Icons.arrow_forward_ios), // Menambahkan ikon panah ke kanan di akhir ListTile.
            onTap: () {
              //tap
            },
          ),
          const Divider(), // Menambahkan garis pemisah horizontal di antara elemen-elemen.
        ],
      ),
    );
  }
}

// Widget untuk menampilkan layanan Pick Up/Delivery
class ServiceOption extends StatelessWidget {
  final IconData icon;
  final String label;
  final String description;
  final Color backgroundColor;
  final Color shadowColor;

  const ServiceOption({
    super.key,
    required this.icon,
    required this.label,
    required this.description,
    required this.backgroundColor,
    required this.shadowColor,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(
          16), // Menambahkan padding sebesar 16 piksel di semua sisi kontainer.
      decoration: BoxDecoration(
        color:
        backgroundColor, // Mengatur warna latar belakang kontainer sesuai dengan nilai dari variabel backgroundColor.
        borderRadius: BorderRadius.circular(12), // Menetapkan radius sudut kontainer sebesar 12 piksel untuk memberikan efek sudut melengkung.
        boxShadow: [
          BoxShadow(
            color: shadowColor .withOpacity(0.5), // Warna bayangan dengan transparansi
            spreadRadius: 2, // Radius penyebaran bayangan
            blurRadius: 5, // Radius blur
            offset: const Offset(0, 3), // Arah bayangan (ke bawah)
          ),
        ],
      ),
      child: Column(
        children: [
          Icon(icon, size: 48, color: Colors.green),
          const SizedBox(height: 8),
          Text(
            label,
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 4),
          Text(
            description,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 14),
          ),
        ],
      ),
    );
  }
}

// Custom widget untuk Service Card
class ServiceCard extends StatelessWidget {
  final String title;
  final String description;
  final IconData icon;
  final Color backgroundColor;

  const ServiceCard({
    Key? key,
    required this.title,
    required this.description,
    required this.icon,
    required this.backgroundColor,
  }) : super(key: key); //memastikan bahwa key diatur dengan benar untuk widget

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(
          16), // Menambahkan padding sebesar 16 piksel di semua sisi kontainer.
      decoration: BoxDecoration(
        color:
        backgroundColor, // Mengatur warna latar belakang kontainer sesuai dengan nilai dari variabel backgroundColor.
        borderRadius: BorderRadius.circular(12), // Menetapkan radius sudut kontainer sebesar 12 piksel untuk memberikan efek sudut melengkung.
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start, // Menyelaraskan elemen dalam kolom ke sisi kiri.
        children: [
          Icon(
            icon, // Menampilkan ikon sesuai dengan nilai dari variabel icon.
            size: 48, // Menetapkan ukuran ikon sebesar 48 piksel.
            color: Colors.white, // Menetapkan warna ikon menjadi putih.
          ),

          const SizedBox(height: 8), // Memberikan jarak vertikal sebesar 8 piksel di antara widget.
          Text(
            title, // Menampilkan teks sesuai dengan nilai dari variabel title.
            style: const TextStyle(
              fontSize: 16, // Menetapkan ukuran font teks sebesar 16 piksel.
              fontWeight:FontWeight.bold, // Menetapkan ketebalan font menjadi bold.
              color: Colors.white, // Menetapkan warna teks menjadi putih.
            ),
          ),
          const SizedBox( height:4), // Memberikan jarak vertikal sebesar 4 piksel di antara widget.
          Text(
            description, // Menampilkan teks sesuai dengan nilai dari variabel description.
            style: const TextStyle(
              fontSize: 12, // Menetapkan ukuran font teks sebesar 12 piksel.
              color: Colors.white, // Menetapkan warna teks menjadi putih.
            ),
          ),
        ],
      ),
    );
  }
}
