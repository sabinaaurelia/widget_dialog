package com.example.widget

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
